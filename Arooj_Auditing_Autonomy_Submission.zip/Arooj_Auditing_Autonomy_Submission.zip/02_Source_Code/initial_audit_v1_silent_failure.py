import pandas as pd
import numpy as np

class DataGovernance:
    def __init__(self, df: pd.DataFrame):
        self.df = df.copy()
        
        # Ensure Datetime typing
        if not pd.api.types.is_datetime64_any_dtype(self.df['Datetime']):
            self.df['Datetime'] = pd.to_datetime(self.df['Datetime'])
            
        # Sort by Datetime to ensure temporal sequence is valid
        self.df = self.df.sort_values('Datetime').reset_index(drop=True)
        
    def check_primary_key(self):
        """1. Identifies exact timestamp duplicates (Row Redundancy)"""
        duplicates = self.df[self.df.duplicated(subset=['Datetime'], keep=False)]
        return duplicates
        
    def check_price_paradoxes(self):
        """2. Identifies mathematical OHLC impossibilities (e.g. High < Low)"""
        mask = (self.df['High'] < self.df['Low']) | \
               (self.df['High'] < self.df['Open']) | \
               (self.df['High'] < self.df['Close']) | \
               (self.df['Low'] > self.df['Open']) | \
               (self.df['Low'] > self.df['Close'])
        return self.df[mask]
        
    def check_temporal_continuity(self):
        """3. Differentiates weekend gaps from erroneous mid-week gaps & overlaps"""
        diffs = self.df['Datetime'].diff()
        
        fifteen_min = pd.Timedelta(minutes=15)
        forty_eight_hours = pd.Timedelta(hours=46) # Lower bound for FX weekend gap
        
        anomalies = self.df[(diffs != fifteen_min) & (diffs.notna())]
        
        # Categorize anomalies
        mid_week_gaps = anomalies[(diffs > fifteen_min) & (diffs < forty_eight_hours)]
        overlaps = anomalies[diffs < fifteen_min] # Flags overlaps/0-minute dupes
        weekend_gaps = anomalies[diffs >= forty_eight_hours]
        
        return mid_week_gaps, overlaps, weekend_gaps
        
    def check_statistical_outliers(self, sigma=5):
        """4. Flags returns or ranges > X Standard Deviations"""
        returns = self.df['Close'].pct_change()
        z_returns = (returns - returns.mean()) / returns.std()
        
        rng = self.df['High'] - self.df['Low']
        z_rng = (rng - rng.mean()) / rng.std()
        
        outliers = self.df[(z_returns.abs() > sigma) | (z_rng.abs() > sigma)].copy()
        outliers['Z_Return'] = z_returns
        outliers['Z_Range'] = z_rng
        return outliers

    def run_audit(self):
        """Executes all checks and prints a production report"""
        print("=== PRODUCTION DATA GOVERNANCE AUDIT ===\n")
        
        # 1. Primary Key Uniqueness
        dupes = self.check_primary_key()
        if not dupes.empty:
            print(f"[FAIL] 1. Primary Key Uniqueness: {len(dupes)} duplicate timestamps found.")
            print(dupes[['Datetime', 'Close']].head(4).to_string(index=True))
        else:
            print("[PASS] 1. Primary Key Uniqueness: 0 duplicates.")
            
        # 2. Physical Price Paradoxes
        paradoxes = self.check_price_paradoxes()
        if not paradoxes.empty:
            print(f"\n[FAIL] 2. Physical Price Paradoxes: {len(paradoxes)} instances found.")
            print(paradoxes[['Datetime', 'Open', 'High', 'Low', 'Close']].head().to_string(index=True))
        else:
            print("\n[PASS] 2. Physical Price Paradoxes: 0 instances.")
            
        # 3. Temporal Continuity
        mid_week, overlaps, weekends = self.check_temporal_continuity()
        print(f"\n[INFO] 3. Temporal Continuity: {len(weekends)} standard weekend gaps detected.")
        if not mid_week.empty or not overlaps.empty:
            print(f"[FAIL] 3. Temporal Continuity: {len(mid_week)} mid-week gaps, {len(overlaps)} overlaps/sub-15m deltas.")
            if not mid_week.empty:
                idx = mid_week.index[0]
                print(f"       Sample Mid-Week Gap at index {idx}:")
                print(self.df.loc[idx-1:idx, ['Datetime', 'Close']].to_string(index=True))
        else:
            print("[PASS] 3. Temporal Continuity: Standard 15m intervals maintained.")
            
        # 4. Statistical Z-Score Outliers
        outliers = self.check_statistical_outliers()
        if not outliers.empty:
            print(f"\n[FAIL] 4. Statistical Z-Score Outliers: {len(outliers)} events > 5 Sigma.")
            print(outliers[['Datetime', 'High', 'Low', 'Close', 'Z_Return', 'Z_Range']].head().to_string(index=True))
        else:
            print("\n[PASS] 4. Statistical Z-Score Outliers: 0 instances.")
# --- EXECUTION BLOCK ---
if __name__ == "__main__":
    try:
        # Load your specific corrupted file
        file_name = 'EURUSD_15M_BATCH_02.csv'
        print(f"Loading {file_name}...")
        
        df = pd.read_csv(file_name)
        
        # Initialize the Governance class
        audit = DataGovernance(df)
        
        # Run the audit
        audit.run_audit()
        
    except FileNotFoundError:
        print("Error: The CSV file was not found. Make sure it is in the same folder as this script!")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")