import pandas as pd
import numpy as np

class DataGovernance:
    def __init__(self, df: pd.DataFrame):
        self.df = df.copy()
        
        # 1. Standardize Datetime BEFORE sorting
        if not pd.api.types.is_datetime64_any_dtype(self.df['Datetime']):
            self.df['Datetime'] = pd.to_datetime(self.df['Datetime'])
            
        # Notice we DO NOT sort or drop the index yet. 
        # This guarantees Primary Key checks execute on the raw sequential order,
        # preserving your original CSV row numbers (e.g., Row 101, 102) for the logs.

    def check_primary_key(self):
        """1. Identifies exact timestamp duplicates (Row Redundancy) using raw order."""
        # keep=False flags ALL instances of the duplicates
        duplicates = self.df[self.df.duplicated(subset=['Datetime'], keep=False)]
        return duplicates
        
    def check_price_paradoxes(self):
        """2. Identifies mathematical OHLC impossibilities."""
        mask = (self.df['High'] < self.df['Low']) | \
               (self.df['High'] < self.df['Open']) | \
               (self.df['High'] < self.df['Close']) | \
               (self.df['Low'] > self.df['Open']) | \
               (self.df['Low'] > self.df['Close'])
        return self.df[mask]
        
    def check_temporal_continuity(self):
        """3. Differentiates weekend gaps from erroneous mid-week gaps & overlaps"""
        # Sort chronologically, but DO NOT drop the index. 
        # This keeps the original CSV row numbers intact for debugging.
        sorted_df = self.df.sort_values('Datetime')
        diffs = sorted_df['Datetime'].diff()
        
        fifteen_min = pd.Timedelta(minutes=15)
        forty_eight_hours = pd.Timedelta(hours=46) 
        
        # Build boolean masks aligned perfectly with sorted_df (Fixes UserWarning)
        mask_valid_diff = diffs.notna()
        mask_anomaly = (diffs != fifteen_min) & mask_valid_diff
        
        mask_mid_week = mask_anomaly & (diffs > fifteen_min) & (diffs < forty_eight_hours)
        mask_overlaps = mask_anomaly & (diffs < fifteen_min)
        mask_weekend = mask_anomaly & (diffs >= forty_eight_hours)
        
        # Apply masks safely to the full sorted dataframe
        mid_week_gaps = sorted_df[mask_mid_week]
        overlaps = sorted_df[mask_overlaps]
        weekend_gaps = sorted_df[mask_weekend]
        
        return mid_week_gaps, overlaps, weekend_gaps, sorted_df
        
    def check_statistical_outliers(self, sigma=5):
        """4. Flags returns or ranges > X Standard Deviations"""
        sorted_df = self.df.sort_values('Datetime')
        
        returns = sorted_df['Close'].pct_change()
        z_returns = (returns - returns.mean()) / returns.std()
        
        rng = sorted_df['High'] - sorted_df['Low']
        z_rng = (rng - rng.mean()) / rng.std()
        
        mask_outlier = (z_returns.abs() > sigma) | (z_rng.abs() > sigma)
        
        outliers = sorted_df[mask_outlier].copy()
        outliers['Z_Return'] = z_returns[mask_outlier]
        outliers['Z_Range'] = z_rng[mask_outlier]
        return outliers

    def run_audit(self):
        """Executes all checks and prints a production report"""
        print("=== PRODUCTION DATA GOVERNANCE AUDIT ===\n")
        
        # 1. Primary Key Uniqueness
        dupes = self.check_primary_key()
        if not dupes.empty:
            print(f"[FAIL] 1. Primary Key Uniqueness: {len(dupes)} duplicate timestamps found.")
            print(dupes[['Datetime', 'Close']].head().to_string(index=True))
        else:
            print("[PASS] 1. Primary Key Uniqueness: 0 duplicates.")
            
        # 2. Physical Price Paradoxes
        paradoxes = self.check_price_paradoxes()
        if not paradoxes.empty:
            print(f"\n[FAIL] 2. Physical Price Paradoxes: {len(paradoxes)} instances found.")
            print(paradoxes[['Datetime', 'Open', 'High', 'Low', 'Close']].head().to_string(index=True))
        else:
            print("\n[PASS] 2. Physical Price Paradoxes: 0 instances.")
            
        # 3. Temporal Continuity
        mid_week, overlaps, weekends, sorted_df = self.check_temporal_continuity()
        print(f"\n[INFO] 3. Temporal Continuity: {len(weekends)} standard weekend gaps detected.")
        if not mid_week.empty or not overlaps.empty:
            print(f"[FAIL] 3. Temporal Continuity: {len(mid_week)} mid-week gaps, {len(overlaps)} overlaps/sub-15m deltas.")
            if not mid_week.empty:
                idx = mid_week.index[0] # Original CSV Index
                print(f"       Sample Mid-Week Gap leading exactly into CSV Row Index {idx}:")
                # Pull positional history so we can show the before-and-after of the gap
                pos = sorted_df.index.get_loc(idx)
                print(sorted_df.iloc[pos-1:pos+1][['Datetime', 'Close']].to_string(index=True))
        else:
            print("[PASS] 3. Temporal Continuity: Standard 15m intervals maintained.")
            
        # 4. Statistical Z-Score Outliers
        outliers = self.check_statistical_outliers()
        if not outliers.empty:
            print(f"\n[FAIL] 4. Statistical Z-Score Outliers: {len(outliers)} events > {5} Sigma.")
            print(outliers[['Datetime', 'High', 'Low', 'Close', 'Z_Return', 'Z_Range']].head().to_string(index=True))
        else:
            print("\n[PASS] 4. Statistical Z-Score Outliers: 0 instances.")

# Execution:
# df = pd.read_csv('EURUSD_15M_BATCH_02.csv')
# audit = DataGovernance(df)
# audit.run_audit()
# --- ACTIVE EXECUTION BLOCK ---
if __name__ == "__main__":
    import pandas as pd
    
    # Load your specific corrupted file
    file_name = 'EURUSD_15M_BATCH_02.csv'
    print(f"Loading {file_name} for Final Verification...")
    
    try:
        df = pd.read_csv(file_name)
        audit = DataGovernance(df)
        audit.run_audit()
    except Exception as e:
        print(f"Error: {e}")