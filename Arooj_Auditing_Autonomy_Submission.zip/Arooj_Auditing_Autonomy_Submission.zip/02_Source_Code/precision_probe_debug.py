import pandas as pd

df = pd.read_csv('EURUSD_15M_BATCH_02.csv')

# Let's look at the rows around 101 and 102 (adjust index if needed)
# Since you're using 0-based indexing in Python, row 101 in Excel might be index 99 or 100
print("--- RAW DATA INSPECTION ---")
print(df.iloc[98:104][['Datetime']])

# Let's check for hidden spaces or special characters
for i, val in enumerate(df.iloc[98:104]['Datetime']):
    print(f"Index {98+i}: '{val}' | Length: {len(str(val))}")