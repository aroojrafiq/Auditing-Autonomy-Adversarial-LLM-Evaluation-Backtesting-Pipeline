import pandas as pd
import numpy as np

# Load Data
df = pd.read_csv('EURUSD_15M_BATCH_02.csv')
df['Datetime'] = pd.to_datetime(df['Datetime'])
df = df.sort_values('Datetime').reset_index(drop=True)

# 1. Data Preparation
paradox_mask = (df['High'] < df['Low']) | (df['High'] < df['Open']) | \
               (df['High'] < df['Close']) | (df['Low'] > df['Open']) | \
               (df['Low'] > df['Close'])
fat_finger_mask = df['High'] > 5.0
df = df[~(paradox_mask | fat_finger_mask)].copy()
df = df.sort_values('Datetime').reset_index(drop=True)

# 2. Add Trend Filter (200 SMA)
df['SMA_200'] = df['Close'].rolling(window=200).mean()

# 3. Identify FVGs
df['FVG_Type'] = None
df['FVG_Top'] = np.nan
df['FVG_Bottom'] = np.nan

high_lag_2 = df['High'].shift(2)
low_lag_2 = df['Low'].shift(2)

bullish_mask = high_lag_2 < df['Low']
bearish_mask = low_lag_2 > df['High']

df.loc[bullish_mask, 'FVG_Type'] = 'Bullish'
df.loc[bullish_mask, 'FVG_Top'] = df['Low']
df.loc[bullish_mask, 'FVG_Bottom'] = high_lag_2

df.loc[bearish_mask, 'FVG_Type'] = 'Bearish'
df.loc[bearish_mask, 'FVG_Top'] = low_lag_2
df.loc[bearish_mask, 'FVG_Bottom'] = df['High']

# 4. Asymmetric Slippage Backtest Engine
balance = 10000.0
pip_value = 1.0 # 0.10 lots = $1 per pip
sl_pips = 15
tp_pips = 30
friction_pips = 1.0

pending_fvgs = []
open_trade = None
trade_history = []

for i in range(200, len(df)):
    current_bar = df.iloc[i]
    trade_closed = False
    
    # A. Process Active Trade
    if open_trade is not None:
        if open_trade['type'] == 'Bullish':
            # 1. Gap Down past SL
            if current_bar['Open'] <= open_trade['sl']:
                slipped_pips = (current_bar['Open'] - open_trade['entry_price']) * 10000
                open_trade['result_pips'] = slipped_pips - friction_pips
                open_trade['sl_slipped'] = True
                trade_closed = True
            # 2. Gap Up past TP (No positive slippage)
            elif current_bar['Open'] >= open_trade['tp']:
                open_trade['result_pips'] = tp_pips - friction_pips
                open_trade['sl_slipped'] = False
                trade_closed = True
            # 3. Intra-bar Stop Loss
            elif current_bar['Low'] <= open_trade['sl']:
                open_trade['result_pips'] = -sl_pips - friction_pips
                open_trade['sl_slipped'] = False
                trade_closed = True
            # 4. Intra-bar Take Profit
            elif current_bar['High'] >= open_trade['tp']:
                open_trade['result_pips'] = tp_pips - friction_pips
                open_trade['sl_slipped'] = False
                trade_closed = True
                
        elif open_trade['type'] == 'Bearish':
            # 1. Gap Up past SL
            if current_bar['Open'] >= open_trade['sl']:
                slipped_pips = (open_trade['entry_price'] - current_bar['Open']) * 10000
                open_trade['result_pips'] = slipped_pips - friction_pips
                open_trade['sl_slipped'] = True
                trade_closed = True
            # 2. Gap Down past TP (No positive slippage)
            elif current_bar['Open'] <= open_trade['tp']:
                open_trade['result_pips'] = tp_pips - friction_pips
                open_trade['sl_slipped'] = False
                trade_closed = True
            # 3. Intra-bar Stop Loss
            elif current_bar['High'] >= open_trade['sl']:
                open_trade['result_pips'] = -sl_pips - friction_pips
                open_trade['sl_slipped'] = False
                trade_closed = True
            # 4. Intra-bar Take Profit
            elif current_bar['Low'] <= open_trade['tp']:
                open_trade['result_pips'] = tp_pips - friction_pips
                open_trade['sl_slipped'] = False
                trade_closed = True
                
        if trade_closed:
            open_trade['result_usd'] = open_trade['result_pips'] * pip_value
            open_trade['exit_time'] = current_bar['Datetime']
            balance += open_trade['result_usd']
            open_trade['balance'] = balance
            trade_history.append(open_trade)
            open_trade = None
            
    # B. Process Pending FVGs (Limit Orders) ONLY if no active trade
    if open_trade is None:
        active_pending = []
        entered = False
        
        for fvg in pending_fvgs:
            if entered:
                break
                
            if i <= fvg['creation_idx'] + 10:
                # Bullish Entry
                if fvg['type'] == 'Bullish' and current_bar['Close'] > current_bar['SMA_200']:
                    if current_bar['Low'] <= fvg['top']:
                        # Exact Limit Fill - No positive slippage
                        entry_price = fvg['top']
                        open_trade = {
                            'entry_time': current_bar['Datetime'],
                            'type': 'Bullish',
                            'entry_price': entry_price,
                            'sl': entry_price - (sl_pips * 0.0001),
                            'tp': entry_price + (tp_pips * 0.0001)
                        }
                        entered = True
                        
                # Bearish Entry
                elif fvg['type'] == 'Bearish' and current_bar['Close'] < current_bar['SMA_200']:
                    if current_bar['High'] >= fvg['bottom']:
                        # Exact Limit Fill - No positive slippage
                        entry_price = fvg['bottom']
                        open_trade = {
                            'entry_time': current_bar['Datetime'],
                            'type': 'Bearish',
                            'entry_price': entry_price,
                            'sl': entry_price + (sl_pips * 0.0001),
                            'tp': entry_price - (tp_pips * 0.0001)
                        }
                        entered = True
                
                if not entered:
                    active_pending.append(fvg)
                    
        if entered:
            pending_fvgs = []
        else:
            pending_fvgs = active_pending
            
    # C. Add New FVG Signals ONLY if no active trade
    if open_trade is None and pd.notna(current_bar['FVG_Type']):
        pending_fvgs.append({
            'creation_idx': i,
            'type': current_bar['FVG_Type'],
            'top': current_bar['FVG_Top'],
            'bottom': current_bar['FVG_Bottom']
        })

if len(trade_history) > 0:
    results_df = pd.DataFrame(trade_history)
    wins = results_df[results_df['result_usd'] > 0]
    losses = results_df[results_df['result_usd'] <= 0]
    
    gross_profit = wins['result_usd'].sum()
    gross_loss = abs(losses['result_usd'].sum())
    profit_factor = gross_profit / gross_loss if gross_loss != 0 else np.nan
    slipped_stops = results_df['sl_slipped'].sum()
    
    print("=== ASYMMETRIC SLIPPAGE BACKTEST RESULTS ===")
    print(f"Total Trades: {len(results_df)}")
    print(f"Slipped Stop Losses: {slipped_stops}")
    print(f"Win Rate: {(len(wins)/len(results_df))*100:.2f}%")
    print(f"Final Equity: ${balance:.2f}")
    print(f"Gross Profit: ${gross_profit:.2f}")
    print(f"Gross Loss: ${gross_loss:.2f}")
    print(f"Profit Factor: {profit_factor:.2f}")
else:
    print("No trades executed.")