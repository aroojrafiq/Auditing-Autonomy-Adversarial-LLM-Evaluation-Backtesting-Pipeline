
# Auditing Autonomy: Gemini 3.1 Pro Evaluation
**Domain:** Quantitative Finance (Forex)  
**Agent Evaluated:** Gemini 3.1 Pro  
**Submission By:** Arooj (Software Engineering Student, UET)

 **Executive Summary:** This evaluation audits Gemini 3.1 Pro's ability to detect deliberately injected data anomalies (logical paradoxes, fat-finger spikes) and construct a friction-aware algorithmic trading backtest. Key finding: The agent exhibits a critical "Chat-Code Chasm" where linguistic output claims success while underlying code execution fails silently.

## 📂 Directory Structure
01_Final_Report/: The comprehensive PDF detailing the methodology, the "Chat-Code Chasm," and the Precision Paradox findings.
* **`02_Source_Code/`**:
    * `data_governance_audit.py`: The finalized, production-ready integrity script.
    * `fvg_backtest_engine.py`: The "Friction-Aware" engine with asymmetric slippage logic.
    * `precision_probe_debug.py`: The forensic tool used to resolve the temporal increment paradox.
    * `initial_audit_v1_silent_failure.py`: **Critical Evidence.** This is the original script that Gemini claimed had "passed" the duplicate check, despite the bug persisting. Compare with `data_governance_audit.py` (the corrected, human-guided version) to see the "Simulation Gap" documented in Section 5.1 of the report.
* ** 03_Data_Assets/`**:
    * EURUSD_15M_BATCH_02.csv`: The neutrally labeled adversarial dataset containing injected anomalies.
    * EURUSD_15M_Reference.csv`: Baseline data used for institutional trend-filter optimization.
*04_Verification_Evidence/`**: High-resolution screenshots of TradingView ground-truth and terminal execution logs (SECTION 3 AND SECTION 5)
*05_Appendix_Transcripts/`**: Full raw text logs of the agentic interaction.

## ⚙️ Technical Requirements
* **Environment:** Python 3.13.5
* **Libraries:** `pandas`, `numpy`
* **Execution:** All scripts are configured to run relative to the root directory using the datasets provided in Folder 03.
 Example:
cd Arooj_Turing_Challenge_Submission
python 02_Source_Code/data_governance_audit.py
python 02_Source_Code/precision_probe_debug.py


